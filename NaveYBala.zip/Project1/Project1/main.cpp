#include <iostream>
#include <stdio.h>
#include "include/SDL.h"
#include <stdlib.h>
#include <exception>
#include <string>

#pragma comment(lib, "lib/x86/SDL2.lib")
#pragma comment(lib, "lib/x86/SDL2main.lib")

using namespace std;

#define WIDTH 1280
#define HEIGHT 720
#define numb 2

int main(int argc, char* args[]) {

	SDL_Window* win = NULL;
	SDL_Renderer* renderer = NULL;
	SDL_Rect miRectangulo;
	SDL_Rect bala[numb];
	SDL_Event event;
	Uint8 *keys;
	int done = 0;
	int numBala = 0;			

	SDL_Init(SDL_INIT_VIDEO);

	win = SDL_CreateWindow("Prueba con cubo azul", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WIDTH, HEIGHT, SDL_WINDOW_SHOWN);

	renderer = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);
	SDL_Texture* ship = SDL_CreateTextureFromSurface(renderer, SDL_LoadBMP("ship.bmp"));
	SDL_Texture* bullet = SDL_CreateTextureFromSurface(renderer, SDL_LoadBMP("bala.bmp"));


	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

	SDL_RenderClear(renderer);

	miRectangulo.x = 50;
	miRectangulo.y = 50;
	miRectangulo.w = 50;
	miRectangulo.h = 50;

	for (int i = 0; i < numb;i++) {
			bala[i].x = -50;
			bala[i].y = -50;
			bala[i].w = 25;
			bala[i].h = 25;
		}

	SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);

	SDL_RenderFillRect(renderer, &miRectangulo);
	SDL_RenderPresent(renderer);
		bool left = false;
		bool right = false;
		bool up = false;
		bool down = false;
		bool space = false;

	while (done==0) {
		//SDL_Event event;


		while (SDL_PollEvent(&event)) {
			switch(event.type){
				case SDL_KEYDOWN:
					switch (event.key.keysym.sym)
					{
						case SDLK_LEFT:  	left = true; break;
						case SDLK_RIGHT: 	right = true; break;
						case SDLK_UP:   	up = true; break;
						case SDLK_DOWN: 	down = true; break;
						case SDLK_ESCAPE:   done = 1; break;
						case SDLK_SPACE:    space = true; break;
					}break;
				case SDL_KEYUP:
					switch (event.key.keysym.sym)
					{
					case SDLK_LEFT:  	left = false; break;
					case SDLK_RIGHT: 	right = false; break;
					case SDLK_UP:   	up = false; break;
					case SDLK_DOWN: 	down = false; break;
					//case SDLK_SPACE:    space = false; break;
					}break;
			}
		}

		if (left == true) {
			if(miRectangulo.x>=0){
			miRectangulo.x -= 2;}
		}
		if (right == true) {
			if(miRectangulo.x<= WIDTH-50){
			miRectangulo.x += 2;}
		}
		if (up == true) {
			if(miRectangulo.y >= 0){
			miRectangulo.y -= 2;}
		}
		if (down == true) {
			if(miRectangulo.y <= HEIGHT - 50){
			miRectangulo.y += 2;}
		}
		if (space == true) {
			bala[numBala].x = miRectangulo.x+25;
			bala[numBala].y = miRectangulo.y;
			numBala++;
			space = false;
			if (numBala == numb) {
				numBala = 0;
			}
		}
		for (int j = 0; j < numb; j++) {
			bala[j].y -= 4;
		}

		//FONDO
		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		SDL_RenderClear(renderer);

		//CUBO
		//SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
		//SDL_RenderFillRect(renderer, &miRectangulo);
		SDL_RenderCopy(renderer, ship, NULL, &miRectangulo);

		//BALA
		for (int i = 0; i < numb; i++) {
			//SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
			SDL_RenderCopy(renderer, bullet, NULL, &bala[i]);
			//SDL_RenderFillRect(renderer, &bala[i]);
		}

		//ACTUALIZAR
		SDL_RenderPresent(renderer);
	}

	SDL_Quit();

	return EXIT_SUCCESS;
 }